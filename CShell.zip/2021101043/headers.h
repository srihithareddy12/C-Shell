#ifndef __HEADERS_H
#define __HEADERS_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <sys/wait.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <grp.h>
#include <pwd.h>
char homedirectory[1000];
char homedirectory1[1000];
char pathstore[1000];
char a[2];
char b[3];
// char *functions[] = {"cd","pwd", "echo","ls","history","pinfo","discover","exit"};
char dir_store[1000];
char dir_store1[1000];
char dir_xx[1000];
int count;
int f_redirec;
char comstore[21][150];
char st_direc[1000];
char qq[1000];
char *BG[10000000] ;


int code_for_cd(char **command, int no_of_arg);
int code_for_echo(char **command, int no_of_arg);
int code_for_pwd(char **command);
int code_for_pinfo(char **command, int no_of_arg);
int store(char *new_command);
int code_for_hist(char **command);
int ls_get(char *path_req, int f1, int f2, int f3, int no_of_arg, char *file_n);
int code_for_ls1(char **command, int no_of_arg);
int discover(char *pathod, int f1, int f2, char *givendir, char *f_o_d, int f3);
int code_for_discover(char **command, int no_of_arg);
void piping(int in, int out, char *command);
int code_for_piping(char *command);
char *code_for_redirection(char *input_);

#endif

