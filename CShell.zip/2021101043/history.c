#include "headers.h"

int store(char *new_command)
{
    // count=count+1;
    int y;
    // printf("%d\n",count);
    if (count == 0)
    {
        if (strcpy(comstore[count], new_command))
            ;
        // printf("%s\n",comstore[count]);
        count++;
    }
    else if (count < 20)
    {
        if (strcmp(comstore[count - 1], new_command) != 0)
        {
            strcpy(comstore[count], new_command);
            //  printf("%s\n",comstore[count]);
            count++;
        }
        // else count=count-1;
    }
    else
    {
        if (strcmp(comstore[count - 1], new_command) != 0)
        {
            for (int i = 1; i < 20; i++)
            {
                strcpy(comstore[i - 1], comstore[i]);
            }
            strcpy(comstore[19], new_command);
            count++;
        }
        // else
        // {
        //     count=count-1;
        // }
    }
    FILE *f = fopen("histt.txt", "w");
    // y = 0;
    if (count >= 20)
    {
        for (int i = 0; i < 20; i++)
        {
            // printf("gg---2\n");
            fprintf(f, "%s\n", comstore[i]);
            // printf("%s",comstore[y]);
        }
    }
    else
    {
        for (int i = 0; i < count; i++)
        {
            // printf("gg---3\n");
            fprintf(f, "%s\n", comstore[i]);
            // printf("%s--k",comstore[y]);
        }
    }
    fclose(f);
}
int code_for_hist(char **command)
{
    if (count > 20)
    {
        for (int i = 0; i < 20; i++)
        {
            printf("%s\n", comstore[i]);
        }
    }
    else if (count >= 10 && count < 20)
    {
        for (int i = count - 10; i < count; i++)
        {
            printf("%s\n", comstore[i]);
        }
    }
    else
    {
        for (int i = 0; i < count; i++)
        {
            // printf("kk--%d",y);
            printf("%s\n", comstore[i]);
        }
    }
}