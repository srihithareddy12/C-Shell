#include "headers.h"

int code_for_cd(char **command, int no_of_arg)
{
    if (no_of_arg==1) 
    {
        chdir(homedirectory);
        return 0;
    }
    else if(no_of_arg>2)
    {
        perror("too many arguments for cd command");
    }
    
    char pathofdirectory[100];
    getcwd(pathofdirectory, 100);

    if(no_of_arg==2)
    {
        char *t = strrchr(command[1], '~');
        char *t1;
        if(t)
        {
            t1=strstr(command[1],"/");
            if(t1)
            {
                char req_dirr[1000];
                strcpy(req_dirr,homedirectory);
                strcat(req_dirr,t1);
                chdir(req_dirr);
                strcpy(dir_store,pathofdirectory);
                return 0;
            }
        }
    }
    char k[2]=".";
    if(strcmp(command[1],k)==0)
    {
        // continue;
    }
    char k2[3]="..";
    if(strcmp(command[1],k2)==0)
    {
        getcwd(dir_store, 1000); 
        getcwd(dir_xx, 1000);
        char kk[20000];
        
        char *f_name;
        long int len_f = 0;
        f_name=strrchr(dir_xx,'/');
        len_f=f_name-dir_xx;   
        strncpy(kk,dir_xx,len_f);
        chdir(kk);
        strcpy(dir_store, kk);
    }
    if(strcmp(command[1],"~")==0)
    {
        getcwd(dir_store, 1000);
        chdir(homedirectory);
    }
     char k4[2]="-";
    if(strcmp(command[1],k4)==0)
    {
        getcwd(dir_store1, 1000);
        chdir(dir_store);
        getcwd(dir_store, 1000);
        strcpy(dir_store,dir_store1);
    }
    // if(chdir(command[1]) != 0)
    // {
    //     perror("there is a problem in cd command arguments:");
    //     return 0;
    // }
    else
    {
            getcwd(dir_store, 1000);
            strcat(pathofdirectory, "/");
            strcat(pathofdirectory, command[1]);
            chdir(pathofdirectory);
    }
}
