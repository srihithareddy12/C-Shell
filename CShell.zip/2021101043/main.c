#include "headers.h"


char *BG[10000000] ={NULL};
char a[2] = "";
char b[3] = " ";

void bg()
{
    int status;
    pid_t pid;
    pid = waitpid(-1, &status, WNOHANG);
    if (pid <= 0)
        return;

    if (status == 0)
        printf("\nProcess %s, with process id = %d, has exited\n", BG[pid], pid);

    else
        printf("\nProcess %s, with process id = %d, FAILED\n", BG[pid], pid);
}

int code_for_exit(char **command)
{
    exit(0);
}


int main(int argc, char *argv[])
{
    char *functions[] = {"cd","pwd", "echo","ls","history","pinfo","discover","exit"};
    char username[1000];
    char host[1000];
    int t_took=0;
    int y=-1;
    int c_a=-1;
    count=0;
    getcwd(homedirectory, 1000);            //path to current working directory initially it is the home directory
    char *buffer;
    buffer = (char *)malloc((1001)*sizeof(char));
    buffer=getlogin();
    if(getlogin_r(buffer,(1001))==0)
    {
       strcpy(username, buffer);
    }
    //else error handling
    gethostname(host, 100);    
    char currentwdir[1500];
    FILE *fp = fopen("histt.txt", "r");
    if(fp == NULL)
    {
        FILE *fp2 = fopen("histt.txt", "w");
        fclose(fp2);
        fp = fopen("histt.txt", "r");
    }
    int no_of_commands=0;
    char temp[2000];
    while(fscanf(fp, "%[^\n]%*c", temp) != EOF)
    {
        strcpy(comstore[no_of_commands++],temp);
    }

    count=no_of_commands;
    fclose(fp);
    
    while (1)
    {

      L:  
        
        getcwd(currentwdir, sizeof(currentwdir));
        char *DIR;
        if (currentwdir != NULL)
        {
            char *p = strstr(currentwdir, homedirectory);
            if(t_took>1 && c_a==0)
            {
                if (p!=NULL)
                {
                    DIR = p + strlen(homedirectory);
                    printf("\033[0;33m<%s@%s:~%s took %ds>\033[0m", username, host, DIR,t_took);
                }
                else
                {
                    printf("\033[0;33m<%s@%s:%s took %ds>\033[0m", username, host,currentwdir,t_took);
                }
            }
            else
            {
                if (p!=NULL)
                {
                    DIR = p + strlen(homedirectory);
                    printf("\033[0;33m<%s@%s:~%s>\033[0m", username, host, DIR);
                }
                else
                {
                    printf("\033[0;33m<%s@%s:%s>\033[0m", username, host,currentwdir);
                }
            }
        c_a=-1;
           
        }
        else
        {
            perror("getcwd() error");
            exit(EXIT_FAILURE);
        }
        char *input = (char *)malloc(sizeof(char) * 3000);
        char input1[3000];
        char R_input[3000];
        
        scanf("%[^\n]%*c", input);
        store(input);

        strcpy(input1, input);
        strcpy(R_input,input);

        int fd1 = dup(1);
        int fd2 = dup(0);
        f_redirec=0;
        char *check1 = strstr(input, ">");
        char *check2 = strstr(input, "<");
        char *check3 = strstr(input, ">>");
        char *checkp=strstr(input," | ");
        // printf("kkk333\n");
        if (check1 != NULL || check2 != NULL || check3 != NULL)
        {
            f_redirec=1;   
            strcpy(input,code_for_redirection(R_input));  
            strcpy(input1, input);    
        }
        if(checkp!=NULL)
        {
            code_for_piping(input);
            dup2(fd1,1);
            close(fd1);
            dup2(fd2,1);
            close(fd2);
            continue;
        }
        int u = 0;
        char *inputbroken1[200];
        inputbroken1[u] = strtok(input,"';','&'");
        while (inputbroken1[u] != NULL)
        {
            u++;
            inputbroken1[u] = strtok(NULL, "';','&'");
        }  
        for (int i = 0; i < u; i++)
        {
            int v = 0;
            char *arg_parts[200];
            arg_parts[v] = strtok(inputbroken1[i], "'\n','\t',' '");
            while (arg_parts[v] != NULL)
            {
                v++;
                arg_parts[v] = strtok(NULL, "'\n','\t',' '");
            }
            if (strcmp(arg_parts[0], functions[0])==0)
            {
                code_for_cd(arg_parts, v);
            }
            else if (strcmp(arg_parts[0], functions[1])==0)
            {
                code_for_pwd(arg_parts);
            }
            else if (strcmp(arg_parts[0], functions[2])==0)
            {
                code_for_echo(arg_parts, v);
            }
            else if (strcmp(arg_parts[0], functions[3])==0)
            {
                code_for_ls1(arg_parts, v);
            }
            else if (strcmp(arg_parts[0], functions[4])==0)
            {
                code_for_hist(arg_parts);
            }
            else if (strcmp(arg_parts[0], functions[5])==0)
            {
                code_for_pinfo(arg_parts, v);
            }
            else if (strcmp(arg_parts[0], functions[6])==0)
            {
                code_for_discover(arg_parts, v);
            }
            else if (strcmp(arg_parts[0], functions[7])==0)
            {
                code_for_exit(arg_parts);
            }
            else
            {  
                time_t t1, t2;
                pid_t p, pi;
                char *token1;
                char *token2;
                int x = 1;
                t1 = time(0);
                char *input_b2[500] = {NULL};
                if (input1[strlen(input1) - 2] == '&')
                    c_a = 1;
                else
                    c_a = 0;
                if (strrchr(input1, '&'))    y = 1;
                else   y = 0;
                
                token1 = strtok(input1, "&");
                input_b2[0] = token1;

                while (token1)
                {
                    token1 = strtok(NULL, "&");
                    if (token1)
                    {
                        input_b2[x] = token1;
                        x++;
                    }
                }

                int i=x-1;
                int k=0;
                while ((i != -1) && (input_b2[i] != NULL))
                {
                    int x1 = 0;
                    char *res_com[500] = {"\0"};
                    
                    token2=strtok(input_b2[i], " \t\n");
                    res_com[x1]=token2;
                    x1++;

                    while (token2)
                    {
                        token2 = strtok(NULL, " \t\n");
                        if (token2 != NULL)
                        {
                            res_com[x1]=token2;
                            x1++;
                        }       
                    }
                    signal(SIGCHLD, bg);
                    p = fork();
                    if (p!=0)
                    {
                        if ((x==2 && y==1 && k==0)||(x==1 && y==0))
                            pi=p;
                        else
                        {
                            BG[p]=res_com[0];
                            printf("[%d] %d\n",x-i,p);
                        }
                        i--;
                        x--;
                    }     
                    else
                    {
                        execvp(res_com[0],res_com);
                    }
                    if((y==1 && k==0 && x==1)||(y==0)) waitpid(pi,NULL,0);
                    k=2;
                }
                t2 = time(0);
                t_took = t2-t1;
                dup2(fd1,1);
                close(fd1);
                dup2(fd2,1);
                close(fd2);
                goto L;
            }
            dup2(fd1,1);
            close(fd1);
            dup2(fd2,1);
            close(fd2);
        }
    }
    return 0;
}
