#include "headers.h"

int code_for_pwd(char **command)
{
    char pathofdirectory[100];
    getcwd(pathofdirectory, 100);
    printf("%s\n", pathofdirectory);
}