#include "headers.h"

char *code_for_redirection(char *input_)
{
    char *command_bits[500];
    int x = 0;
    command_bits[x] = strtok(input_, b);
    int x1=-1, x2=-1;
    int check_I=0,check_O = 0,p_check=-1;
    int flag2 = -1,p_flag = -1;

    while (command_bits[x] != NULL)
    {
        if (strcmp(command_bits[x], "<") == 0)
        {
            if (check_I == 1)
            {
                printf("error\n");
                return a;
            }
            x1 = x;
            check_I = 1;   
        }
        else if (strcmp(command_bits[x], ">") == 0)
        {
            if (check_O == 1)
            {
                printf("error\n");
                return a;
            }
            x2 = x;
            check_O = 1;
           
        }
        else if (strcmp(command_bits[x], ">>") == 0)
        {
            if (check_O == 1)
            {
                printf("syntax error\n");
                return a;
            }
            x2 = x;
            flag2 = 0;
            check_O = 1;   
        }
        else if (strcmp(command_bits[x], "|") == 0 && p_flag == -1)
        {
            p_flag = 0;
            p_check=x;
        }
        
        x++;
        command_bits[x] = strtok(NULL, b);    
    }
    if(x2==-1) x2=x+1;
    if (x>20)
    {
        printf("Invalid! too many commands\n");
        return b;
    }
    
    int fd;
    if (x2 < x)
    {
        if (flag2) fd = open(command_bits[x2+1], O_WRONLY | O_CREAT | O_TRUNC,0644); 
        else  fd = open(command_bits[x2+1], O_WRONLY | O_CREAT | O_APPEND,0644);

        if (dup2(fd, STDOUT_FILENO) < 0)
        {
            perror("Can't duplicate fd.");
            close(fd);
            return a;
        }
        close(fd);
    }
    else if (x2==x||x1==0) return a;
    if(x2==(x+1)) x2=x;

    char *command = malloc(3000);
    strcpy(command,a);
    
    for (int i=0;i<x2;i++)
    {
        if(strcmp(command_bits[i], "<")!=0) 
        {
            strcat(command, command_bits[i]);
             strcat(command, b);
        } 
    }
    return command;
}