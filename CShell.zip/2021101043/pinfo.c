#include "headers.h"

int code_for_pinfo(char **command, int no_of_arg)
{

    long int pid_val = 0;
    if (no_of_arg == 1)
    {
        pid_val = getpid();
    }
    if (no_of_arg == 2)
    {
        pid_val = atoi(command[1]);
    }
    if (no_of_arg > 2)
    {
        perror("Too many arguments");
        return 0;
    }
    printf("pid : %ld\n", pid_val);
    // if(exlen<0)
    // 	perror("sym link error");
    // else{
    // 	exec[exlen]='\0'; //NULL
    // 	// printf("executable -- %s\n",exec);
    char path[1000];
    sprintf(path, "/proc/%ld/stat", pid_val);
    FILE *fp1 = fopen(path, "r");

    if (fp1 == NULL)
    {
        perror("error");
    }
    else
    {
        // printf("dd\n");
        long int memory = 0;
        long long int tpgid = -1;
        char status;
        long long int pgrp = -1;
        char buffer[10000];

        fscanf(fp1, "%*s %*s %c %*s %lld %*s %*s %lld %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s", &status, &pgrp, &tpgid);
        if (pgrp == tpgid)
            printf("Process Status : %c+\n", status);
        else
            printf("Process Status : %c\n", status);
        fclose(fp1);

        sprintf(path, "/proc/%ld/statm", pid_val);
        FILE *fp1 = fopen(path, "r");
        fscanf(fp1, "%ld", &memory);
        printf("memory : %ld\n", memory);
        fclose(fp1);

        sprintf(path, "/proc/%ld/exe", pid_val);
        readlink(path, buffer, 1000);
        // printf("%s\n", buffer);

        char *relpath = strstr(buffer, homedirectory);
        int len = strlen(homedirectory);

        if (relpath)
        {
            relpath = relpath + len;
            char temp[1000];
            strcpy(temp, "~");
            strcat(temp, relpath);
            printf("executable path : %s\n", temp);
        }
        else
        {
            printf("executable path : %s\n", buffer);
        }
    }
}