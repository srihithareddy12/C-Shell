#include "headers.h"

int compare(const void *a, const void *b)
{
    const char **str_a = (const char **)a;
    const char **str_b = (const char **)b;
    return strcasecmp(*str_a, *str_b);
}
int ls_get(char *path_req, int f1, int f2, int f3, int no_of_arg, char *file_n)
{
    int q = 0;
    char pathofdirectory[1000];
    strcpy(pathofdirectory, path_req);
    char *fnames_in_dir1[1000];
    int count = 0;
    char kk1[2000];
    if (f2 == 0 && f3 == 0)
    {
        DIR *dir_handle = opendir(pathofdirectory);

        struct dirent *dir;
        if (dir_handle)
        {
            while ((dir = readdir(dir_handle)) != NULL)
            {
                if (f1 == 0)
                {
                    if (dir->d_name[0] != '.')
                    {
                        fnames_in_dir1[count] = dir->d_name;
                        count++;
                    }
                }
                else
                {
                    fnames_in_dir1[count] = dir->d_name;
                    count++;
                }
            }
            qsort(fnames_in_dir1, count, sizeof(char *), compare);
            for (int i = 0; i < count; i++)
            {
                strcpy(kk1, pathofdirectory);
                strcat(kk1, "/");
                strcat(kk1, fnames_in_dir1[i]);

                struct stat fs2 = {0};
                if (stat(kk1, &fs2) == 0)
                {
                    if(f_redirec=0)
                    {
                        if (fs2.st_mode & S_IFDIR)
                        {
                            printf("\033[0;34m%s\n\033[0m", fnames_in_dir1[i]);
                        }
                        else if (fs2.st_mode & S_IXUSR)
                        {
                            printf("\033[0;32m%s\n\033[0m", fnames_in_dir1[i]);
                        }
                        else
                            printf("%s\n", fnames_in_dir1[i]);
                    }
                    else
                    {
                        printf("%s\n", fnames_in_dir1[i]);
                    }
                    
                }
            }
            closedir(dir_handle);
        }
        else
        {
            printf("Cannot open current directory");
            return 0;
        }
    }
    if (f2 == 1 && f1 == 0 && f3 == 0)
    {
        char *fnames_in_dir[3000];
        DIR *dir_handle = opendir(pathofdirectory);
        struct dirent *dir;
        if (dir_handle)
        {
            int count = 0, total = 0;
            while ((dir = readdir(dir_handle)) != NULL)
            {
                char k1[1000];
                char k3[1000];
                char *k2;
                k2 = getcwd(k1, 1000);
                strcat(k2, "/");
                strcpy(k3, k2);
                strcat(k3, dir->d_name);
                struct stat direc = {0};
                if (dir->d_name[0] != '.')
                {
                    fnames_in_dir[count] = dir->d_name;
                    count++;
                    if (stat(k3, &direc) == 0)
                        total += direc.st_blocks;
                    // printf("%s\n", dir->d_name);
                }
            }
            printf("total %d\n", total / 2);
            qsort(fnames_in_dir, count, sizeof(char *), compare);
            char kk[1000];

            for (int i = 0; i < count; i++)
            {
                strcpy(kk, pathofdirectory);
                strcat(kk, "/");
                strcat(kk, fnames_in_dir[i]);

                struct stat fs = {0};
                int r = stat(kk, &fs);
                if (stat(kk, &fs) == 0)
                {
                    if (fs.st_mode & S_IFDIR)
                        printf("d");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IROTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWOTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXOTH)
                        printf("r");
                    else
                        printf("-");
                    printf(" ");
                    printf("%ld ", fs.st_nlink);
                    struct passwd *oid = getpwuid(fs.st_uid);
                    if (oid != 0)
                        printf("%s ", oid->pw_name);
                    struct group *grpid = getgrgid(fs.st_gid);
                    if (grpid != 0)
                        printf("%s ", grpid->gr_name);
                    printf("%5ld ", fs.st_size);
                    char mtime[80];
                    time_t t = fs.st_mtime;
                    struct tm lt;
                    localtime_r(&t, &lt);
                    strftime(mtime, sizeof mtime, "%b %d %Y %H:%M", &lt);
                    printf("%s ", mtime);
                    //  printf("%s---s", fnames_in_dir1[i]);
                    if (fs.st_mode & S_IFDIR)
                    {
                        printf("\033[0;34m%s\n\033[0m", fnames_in_dir[i]);
                    }
                    else if (fs.st_mode & S_IXUSR)
                    {
                        printf("\033[0;32m%s\n\033[0m", fnames_in_dir[i]);
                    }
                    else
                        printf("%s\n", fnames_in_dir[i]);
                }
                else
                {
                    perror("Error reading file permissions");
                }
            }
            closedir(dir_handle);
        }
        else
        {
            printf("Cannot open current directory");
            return 0;
        }
    }
    if ((f2 == 3) || (f2 == 1 && f1 == 1))
    {
        DIR *dir_handle = opendir(pathofdirectory);
        struct dirent *dir;
        if (dir_handle)
        {
            int total = 0;
            while ((dir = readdir(dir_handle)) != NULL)
            {
                char k1[1000];
                char k3[1000];
                char *k2;
                k2 = getcwd(k1, 1000);
                strcat(k2, "/");
                strcpy(k3, k2);
                strcat(k3, dir->d_name);
                struct stat direc = {0};

                fnames_in_dir1[count] = dir->d_name;
                count++;
                if (stat(k3, &direc) == 0)
                    total += direc.st_blocks;
                // printf("%s\n", dir->d_name);
            }
            printf("total %d\n", total / 2);
            qsort(fnames_in_dir1, count, sizeof(char *), compare);
            char kk[1000];

            for (int i = 0; i < count; i++)
            {
                strcpy(kk, pathofdirectory);
                strcat(kk, "/");
                strcat(kk, fnames_in_dir1[i]);

                struct stat fs = {0};
                int r = stat(kk, &fs);
                if (stat(kk, &fs) == 0)
                {
                    if (fs.st_mode & S_IFDIR)
                        printf("d");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IROTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWOTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXOTH)
                        printf("r");
                    else
                        printf("-");
                    printf(" ");
                    printf("%ld ", fs.st_nlink);
                    struct passwd *oid = getpwuid(fs.st_uid);
                    if (oid != 0)
                        printf("%s ", oid->pw_name);
                    struct group *grpid = getgrgid(fs.st_gid);
                    if (grpid != 0)
                        printf("%s ", grpid->gr_name);
                    printf("%5ld ", fs.st_size);
                    char mtime[80];
                    time_t t = fs.st_mtime;
                    struct tm lt;
                    localtime_r(&t, &lt);
                    strftime(mtime, sizeof mtime, "%b %d %Y %H:%M", &lt);
                    printf("%s ", mtime);

                    if (fs.st_mode & S_IFDIR)
                    {
                        // printf("\033[0;34m");
                        // printf("%s\n", fnames_in_dir1[i]);
                        // printf("\033[0m");
                        printf("\033[0;34m%s\n\033[0m", fnames_in_dir1[i]);
                    }
                    else if (fs.st_mode & S_IXUSR)
                    {
                        // printf("\033[0;32m");
                        printf("\033[0;32m%s\n\033[0m", fnames_in_dir1[i]);
                        // printf("\033[0m");
                    }
                    else
                        printf("%s\n", fnames_in_dir1[i]);
                }
                else
                {
                    perror("Error reading file permissions");
                }
            }
            closedir(dir_handle);
        }
    }
    // printf("lll\n");
    if (f3 == 2 && f2 == 0)
    {
        printf("lll\n");
        DIR *dir_handle = opendir(pathofdirectory);
        struct dirent *dir;
        if (dir_handle)
        {
            while ((dir = readdir(dir_handle)) != NULL)
            {
                if (f1 == 0)
                {
                    if (dir->d_name[0] != '.')
                    {
                        fnames_in_dir1[count] = dir->d_name;
                        count++;
                    }
                }
                else
                {
                    fnames_in_dir1[count] = dir->d_name;
                    count++;
                }
            }
            qsort(fnames_in_dir1, count, sizeof(char *), compare);
            for (int i = 0; i < count; i++)
            {
                strcpy(kk1, pathofdirectory);
                strcat(kk1, "/");
                strcat(kk1, fnames_in_dir1[i]);
                struct stat fs2 = {0};
                if (stat(kk1, &fs2) == 0)
                {
                    if (fs2.st_mode & S_IFDIR)
                    {
                        printf("\033[0;34m%s\n\033[0m", fnames_in_dir1[i]);
                    }
                    else if (fs2.st_mode & S_IXUSR)
                    {
                        printf("\033[0;32m%s\n\033[0m", fnames_in_dir1[i]);
                    }
                    else
                        printf("%s\n", fnames_in_dir1[i]);
                }
            }
            closedir(dir_handle);
        }
        else
        {
            printf("Cannot open current directory");
            return 0;
        }
    }
    if (f3 == 2 && (f2 == 1 || f2 == 3))
    {
        printf("kk--1\n");
        if (f2 == 3)
        {
            f2 = 1;
            f1 = 1;
        }
        DIR *dir_handle = opendir(pathofdirectory);
        struct dirent *dir;
        if (dir_handle)
        {
            int count = 0, total = 0;
            while ((dir = readdir(dir_handle)) != NULL)
            {
                char k1[1000];
                char *k2;
                k2 = getcwd(k1, 1000);
                char k3[1000];
                strcat(k2, "/");
                strcpy(k3, k2);
                strcat(k3, dir->d_name);
                struct stat direc = {0};
                if (f1 == 0)
                {
                    if (dir->d_name[0] != '.')
                    {
                        fnames_in_dir1[count] = dir->d_name;
                        count++;
                        if (stat(k3, &direc) == 0)
                            total += direc.st_blocks;
                    }
                }
                else
                {
                    fnames_in_dir1[count] = dir->d_name;
                    count++;
                    if (stat(k3, &direc) == 0)
                        total += direc.st_blocks;
                }
            }
            printf("total %d\n", total / 2);
            qsort(fnames_in_dir1, count, sizeof(char *), compare);

            char kk[1000];
            for (int i = 0; i < count; i++)
            {
                strcpy(kk1, pathofdirectory);
                strcat(kk1, "/");
                strcat(kk1, fnames_in_dir1[i]);
                struct stat fs = {0};
                if (stat(kk1, &fs) == 0)
                {
                    if (fs.st_mode & S_IFDIR)
                        printf("d");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IROTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWOTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXOTH)
                        printf("r");
                    else
                        printf("-");
                    printf(" ");
                    printf("%ld ", fs.st_nlink);
                    struct passwd *oid = getpwuid(fs.st_uid);
                    if (oid != 0)
                        printf("%s ", oid->pw_name);
                    struct group *grpid = getgrgid(fs.st_gid);
                    if (grpid != 0)
                        printf("%s ", grpid->gr_name);
                    printf("%5ld ", fs.st_size);
                    char mtime[80];
                    time_t t = fs.st_mtime;
                    struct tm lt;
                    localtime_r(&t, &lt);
                    strftime(mtime, sizeof mtime, "%b %d %Y %H:%M", &lt);
                    printf("%s ", mtime);
                    if (fs.st_mode & S_IFDIR)
                    {
                        printf("\033[0;34m%s\n\033[0m", fnames_in_dir1[i]);
                    }
                    else if (fs.st_mode & S_IXUSR)
                    {
                        printf("\033[0;32m%s\n\033[0m", fnames_in_dir1[i]);
                    }
                    else
                        printf("%s\n", fnames_in_dir1[i]);
                }
            }
            closedir(dir_handle);
        }
        else
        {
            printf("Cannot open current directory");
            return 0;
        }
    }
    if (f3 == 3)
    {
        char x[1000];
        DIR *dir_handle = opendir(pathofdirectory);
        struct dirent *dir;
        if (dir_handle)
        {
            while ((dir = readdir(dir_handle)) != NULL)
            {
                if (f1 == 0)
                {
                    if (dir->d_name[0] != '.')
                    {
                        if (strcmp(file_n, dir->d_name) == 0)
                        {
                            strcpy(x, dir->d_name);
                        }
                    }
                }
                if (f1 == 1)
                {
                    if (strcmp(file_n, dir->d_name) == 0)
                    {
                        strcpy(x, dir->d_name);
                    }
                }
            }
            strcpy(kk1, pathofdirectory);
            strcat(kk1, "/");
            strcat(kk1, x);
            struct stat fs = {0};
            if (stat(kk1, &fs) == 0)
            {
                if (f2)
                {
                    if (fs.st_mode & S_IFDIR)
                        printf("d");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXUSR)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IRGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXGRP)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IROTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IWOTH)
                        printf("r");
                    else
                        printf("-");
                    if (fs.st_mode & S_IXOTH)
                        printf("r");
                    else
                        printf("-");
                    printf(" ");
                    printf("%ld ", fs.st_nlink);
                    struct passwd *oid = getpwuid(fs.st_uid);
                    if (oid != 0)
                        printf("%s ", oid->pw_name);
                    struct group *grpid = getgrgid(fs.st_gid);
                    if (grpid != 0)
                        printf("%s ", grpid->gr_name);
                    printf("%5ld ", fs.st_size);
                    char mtime[80];
                    time_t t = fs.st_mtime;
                    struct tm lt;
                    localtime_r(&t, &lt);
                    strftime(mtime, sizeof mtime, "%b %d %Y %H:%M", &lt);
                    printf("%s ", mtime);
                }
                if (fs.st_mode & S_IXUSR)
                {
                    printf("\033[0;32m");
                    printf("%s\n", x);
                    printf("\033[0m");
                }
                else
                    printf("%s\n", x);
            }
        }
        closedir(dir_handle);
    }
}
int code_for_ls1(char **command, int no_of_arg)
{
    int x1 = 0;
    int x2 = 0;
    int x3 = 0;
    int x4 = 0;
    int count1 = 0;
    int count2 = 0;
    char pathofdirectory[100];
    getcwd(pathofdirectory, 100);
    if (no_of_arg == 1)
    {
        strcpy(homedirectory1, homedirectory);

        ls_get(homedirectory1, x1, x2, x3, no_of_arg, a);
    }
    if (no_of_arg > 1)
    {
        char checkfd1[10][1000];
        char checkfd2[10][1000];
        char checkfd3[10][1000];
        char fn[1000];
        char invoked[4000];
        getcwd(invoked, 4000);
        strcpy(homedirectory1, invoked);
        for (int i = 1; i < no_of_arg; i++)
        {
            if (strcmp(command[i], "-a") == 0)
                x1 = 1;
            else if (strcmp(command[i], "-l") == 0)
                x2 = 1;
            else if (strcmp(command[i], "-al") == 0)
                x2 = 3;
            else if (strcmp(command[i], "-la") == 0)
                x2 = 3;
            else if (strcmp(command[i], ".") == 0)
                strcpy(homedirectory1, invoked);
            else if (strcmp(command[i], "~") == 0)
            {
                strcpy(homedirectory1, homedirectory);
                // x4=1;
            }
            else if (strcmp(command[i], "..") == 0)
            {
                // x4=3;
                char kk1[20000];
                char *f_name;
                long int len_f = 0;
                f_name = strrchr(pathofdirectory, '/');
                len_f = f_name - pathofdirectory;
                strncpy(kk1, pathofdirectory, len_f);
                strcpy(homedirectory1, kk1);
            }
            else
            {
                strcpy(homedirectory1, pathofdirectory);
                char kk2[1000];
                strcpy(kk2, pathofdirectory);
                strcat(kk2, "/");
                strcat(kk2, command[i]);
                // int t=0;
                struct stat fs2 = {0};
                if (stat(kk2, &fs2) == 0)
                {
                    if (fs2.st_mode & S_IFDIR)
                    {
                        x3 = 2;
                        strcpy(checkfd1[count1], kk2);
                        strcpy(checkfd3[count1], command[i]);
                        count1++;
                    }
                    else if (fs2.st_mode & S_IFREG)
                    {
                        x4 = 3;
                        strcpy(checkfd2[count2], command[i]);
                        count2++;
                    }
                }
                else
                {
                    perror("Error reading file permissions");
                }
            }
        }
        for (int i = 0; i < count2; i++)
        {
            x3 = 3;
            ls_get(homedirectory1, x1, x2, x3, no_of_arg, checkfd2[i]);
        }
        for (int i = 0; i < count1; i++)
        {
            x3 = 2;
            printf("====================%s:\n", checkfd3[i]);
            ls_get(checkfd1[i], x1, x2, x3, no_of_arg, a);
        }
        if (count1 == 0 && count2 == 0)
        {
            ls_get(homedirectory1, x1, x2, x3, no_of_arg, a);
        }
        // ls_get(homedirectory1,x1,x2,x3,no_of_arg);
    }
}