#include "headers.h"

int discover(char *pathod, int f1, int f2, char *givendir, char *f_o_d, int f3)
{
    if (f1 == 0 && f2 == 0)
    {
        f1 = 1;
        f2 = 1;
    }
    DIR *dir_handle = opendir(pathod);
    struct dirent *dir;
    if (dir_handle)
    {
        char kk[1000];
        while ((dir = readdir(dir_handle)) != NULL)
        {
            struct stat fs1 = {};
            strcpy(kk, pathod);
            strcat(kk, "/");
            strcat(kk, dir->d_name);
            if (stat(kk, &fs1) == 0)
            {
                if (f1 == 1)
                {
                    if (fs1.st_mode & S_IFREG)
                    {
                        if (strcmp(givendir, a) == 0)
                        {
                            if (strcmp(f_o_d, a) == 0)
                            {
                                if (f3 == 2)
                                    printf("%s/%s\n", pathstore, dir->d_name);
                                else if (f3 == 1)
                                    printf("%s/%s\n", homedirectory, dir->d_name);
                                else if (f3 == 3)
                                    printf("../%s\n", dir->d_name);
                                else
                                    printf("./%s\n", dir->d_name);
                            }
                            else
                            {
                                if (strcmp(f_o_d, dir->d_name) == 0)
                                {
                                    char *k = strrchr(pathod, '/');
                                    if (f3 == 2)
                                        printf("%s/%s\n", pathstore, dir->d_name);
                                    else if (f3 == 1)
                                        printf("%s/%s\n", homedirectory, dir->d_name);
                                    else if (f3 == 3)
                                        printf("../%s\n", dir->d_name);
                                    else
                                        printf("./%s\n", dir->d_name);
                                }
                            }
                        }
                        else
                        {
                            if (strcmp(f_o_d, a) == 0)
                            {
                                if (f3 == 2)
                                    printf("%s%s/%s\n", pathstore, givendir, dir->d_name);
                                else if (f3 == 1)
                                    printf("%s%s/%s\n", homedirectory, givendir, dir->d_name);
                                else if (f3 == 3)
                                    printf("..%s/%s\n", givendir, dir->d_name);
                                else
                                    printf(".%s/%s\n", givendir, dir->d_name);
                            }
                            else
                            {
                                if (strcmp(f_o_d, dir->d_name) == 0)
                                {
                                    if (f3 == 2)
                                        printf("%s%s/%s\n", pathstore, givendir, dir->d_name);
                                    else if (f3 == 1)
                                        printf("%s%s/%s\n", homedirectory, givendir, dir->d_name);
                                    else if (f3 == 3)
                                        printf("..%s/%s\n", givendir, dir->d_name);
                                    else
                                        printf(".%s/%s\n", givendir, dir->d_name);
                                }
                            }
                        }
                    }
                }
                if (f2 == 1)
                {
                    if (fs1.st_mode & S_IFDIR)
                    {
                        char *k = strrchr(pathod, '/');
                        if (dir->d_name[0] != '.')
                        {
                            if (strcmp(givendir, a) == 0)
                            {
                                if (strcmp(f_o_d, a) == 0)
                                {
                                    if (f3 == 2)
                                        printf("%s/%s\n", pathstore, dir->d_name);
                                    else if (f3 == 1)
                                        printf("%s/%s\n", homedirectory, dir->d_name);
                                    else if (f3 == 3)
                                        printf("../%s\n", dir->d_name);
                                    else
                                        printf("./%s\n", dir->d_name);
                                }
                                else
                                {
                                    if (strcmp(f_o_d, dir->d_name) == 0)
                                    {
                                        if (f3 == 2)
                                            printf("%s/%s\n", pathstore, dir->d_name);
                                        else if (f3 == 1)
                                            printf("%s/%s\n", homedirectory, dir->d_name);
                                        else if (f3 == 3)
                                            printf("../%s\n", dir->d_name);
                                        else
                                            printf("./%s\n", dir->d_name);
                                    }
                                }
                            }
                            else
                            {
                                if (strcmp(f_o_d, a) == 0)
                                {
                                    if (f3 == 2)
                                        printf("%s%s/%s\n", pathstore, givendir, dir->d_name);
                                    else if (f3 == 1)
                                        printf("%s%s/%s\n", homedirectory, givendir, dir->d_name);
                                    else if (f3 == 3)
                                        printf("..%s/%s\n", givendir, dir->d_name);
                                    else
                                        printf(".%s/%s\n", givendir, dir->d_name);
                                }
                                else
                                {
                                    if (strcmp(f_o_d, dir->d_name) == 0)
                                    {
                                        if (f3 == 2)
                                            printf("%s%s/%s\n", pathstore, givendir, dir->d_name);
                                        else if (f3 == 1)
                                            printf("%s%s/%s\n", homedirectory, givendir, dir->d_name);
                                        else if (f3 == 3)
                                            printf("..%s/%s\n", givendir, dir->d_name);
                                        else
                                            printf(".%s/%s\n", givendir, dir->d_name);
                                    }
                                }
                            }
                        }
                    }
                }
                if (fs1.st_mode & S_IFDIR && dir->d_name[0] != '.')
                {
                    strcat(qq, "/");
                    strcat(qq, dir->d_name);
                    discover(kk, f1, f2, qq, f_o_d, f3);
                    strcpy(qq, &pathod[strlen(homedirectory1)]);
                }
            }
        }
        closedir(dir_handle);
    }
}
int code_for_discover(char **command, int no_of_arg)
{
    char pathofdirectory[100];
    getcwd(pathofdirectory, 100);
    if (no_of_arg == 1)
    {
        strcpy(homedirectory1, homedirectory);
        discover(pathofdirectory, 0, 0, a, a, 0);
    }
    if (no_of_arg == 3 || no_of_arg == 4 || no_of_arg == 2)
    {
        int x1 = 0;
        int x2 = 0;
        int x3 = 0;
        int x4 = 0;
        char fn[1000];
        char invoked[4000];
        getcwd(invoked, 4000);
        strcpy(homedirectory1, invoked);
        for (int i = 1; i < no_of_arg; i++)
        {
            if (strcmp(command[i], "-f") == 0)
                x1 = 1;
            else if (strcmp(command[i], "-d") == 0)
                x2 = 1;
            else if (strcmp(command[i], ".") == 0)
                strcpy(homedirectory1, invoked);
            else if (strcmp(command[i], "~") == 0)
            {
                strcpy(homedirectory1, homedirectory);
                x4 = 1;
            }
            else if (strcmp(command[i], "..") == 0)
            {
                x4 = 3;
                char kk1[20000];
                char *f_name;
                long int len_f = 0;
                f_name = strrchr(pathofdirectory, '/');
                len_f = f_name - pathofdirectory;
                strncpy(kk1, pathofdirectory, len_f);
                strcpy(homedirectory1, kk1);
            }
            else if (command[i][0] == '.')
            {
                if (command[i][1] == '/')
                {
                    x4 = 2;
                    strcpy(pathstore, command[i]);
                    strcat(homedirectory1, &command[i][1]);
                }
            }
            else if (command[i][0] == '"')
            {
                x3 = 1;
                int l = strlen(command[i]);
                char kk2[1000];
                strcpy(kk2, a);
                // printf("%s",kk2);
                strncpy(kk2, &command[i][1], l - 2);
                // printf("%s",command[i]);
                // printf("%s",kk2);
                kk2[l - 2] = '\0';
                strcpy(fn, kk2);
                // printf("%s\n", &kk2[l - 1]);
                // printf("%s\n",fn);
                // printf("%s\n",kk2);
            }
            else
            {
                x4 = 2;
                // strcpy(pathstore,"./");
                strcat(pathstore, command[i]);
                strcat(homedirectory1, "/");
                strcat(homedirectory1, command[i]);
                // printf("%s\n",homedirectory1);
            }
        }
        // if(x)
        if (x3 == 1)
        {
            discover(homedirectory1, x1, x2, a, fn, x4);
        }
        else
        {
            discover(homedirectory1, x1, x2, a, a, x4);
        }
    }
}