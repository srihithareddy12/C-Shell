#include "headers.h"

int code_for_echo(char **command, int no_of_arg)
{
    if (strcmp(command[no_of_arg - 1], "echo") != 0)
    {
        for (int i = 1; i < no_of_arg - 1; i++)
            printf("%s ", command[i]);
        printf("%s\n", command[no_of_arg - 1]);
    }
    else
    {
        printf("\n");
    }
}