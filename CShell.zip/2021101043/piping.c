#include "headers.h"

int x = 0;
void piping(int fd1,int fd2,char *command)
{   
    int p = fork();
    if (p==0)
    {
        if (fd1!= 0)
        {
            dup2(fd1,0);
            close(fd1);
        }
        if (fd2 != 1 && x==0)
        {
            dup2(fd2,1);
            close(fd2);
        }
        // printf("13\n");
        int v = 0;
        char *res_com[200];
        res_com[v] = strtok(command, " ");
        while(res_com[v]!=NULL)
        {
            v++;
            res_com[v]=strtok(NULL, " ");
        }
        // printf("14\n");
        if (strcmp(res_com[0], "pinfo") == 0)
            code_for_pinfo(res_com,v);
        else
        {
            // printf("ppppppppl\n");
            execvp(res_com[0], res_com);
            // printf("lll\n");
        }
        // printf("KKKKKKKKKK\n");
    }
    else 
    {
        int status;
        waitpid(p,&status,0);
        return;
    }
    // printf("ku,olo\n");
}

int code_for_piping(char *command)
{  
    int fd[2], fd2 = 0;
    int i = 0;
    x = 0;
    char *x_commands[10000];
    x_commands[i] = strtok(command, "|");
    while (x_commands[i] != NULL)
    {    
        i++;
        x_commands[i]=strtok(NULL,"|");
    }
    for (int j=0;j<i;j++)
    {
        if (pipe(fd)<0)
        {
            perror("error ocuured while creating PIPE");
            return 0;
        }
        if(j==i-1)  x=1;
        piping(fd2,fd[1],x_commands[j]);
        // printf("uik\n");
        fd2 = fd[0];
        close(fd[1]);
    }
    return 1;
}
